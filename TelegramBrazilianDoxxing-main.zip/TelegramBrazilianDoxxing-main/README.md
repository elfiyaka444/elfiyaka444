<h1 align="center">TelegramBrazilianDoxxing</h1>

<p align="center">
  <img src="https://github.com/Kiny-Kiny/TelegramBrazilianDoxxing/blob/main/asserts/01.gif"/>
</p>

<p align="center">
  <a href="https://github.com/Kiny-Kiny/TelegramBrazilianDoxxing/blob/main/asserts/example.md">Example</a> •
  <a href="https://github.com/Kiny-Kiny/TelegramBrazilianDoxxing/blob/main/asserts/main.md">Install & Run</a> •
  <a href="https://youtube.com/c/reKINYCRIMSONLOL">Youtube Channel</a> •
  <a href="https://github.com/Kiny-Kiny">Author</a>
</p>

<h2 align="center">Requirements</h2>

- **python 3.9**

- **python-socks**

- **telethon**
 
- **requests**

- **ujson**

 <h2 align="center">💰 Donate</h2>
 
 - Chave **Pix** para ajudar a manter o projeto ativo:
 ```
  06acdbe2-ccf2-4c14-b8c1-7f0c965f629d
 ```

<h2 align="center">✉️ Contact</h2>
<p align="center" >
  <a href="http://t.me/k_iny" alt="Telegram">
    <img src = "https://img.shields.io/badge/-Telegram-1ca0f1?style=for-the-badge&labelColor=1ca0f1&logo=telegram&logoColor=white&link=https://t.me/k_iny" /> </a>
</p>

<h2 align="center">Update(s):</h2>

| Date           | Change(s)                                                                  |
| -------------- |:-------------:                                                         |
| 30-03-22       | Consulta de Placa adicionada              
| 08-04-22       | Consulta de RG e Email adicionadas
| 10-04-22       | Novas consultas removidas temporariamente
| 14-04-22       | Consulta de RG adicionada novamente
| 26-04-22       | Consulta de Foto adicionada
| 27-04-22.      | Nova base de CPF adicionada e consulta de Email adicionada novamente
