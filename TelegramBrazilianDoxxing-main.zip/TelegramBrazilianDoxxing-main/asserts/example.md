```
~/TelegramBrazilianDoxxing $ python3 main.py /cpf 00000000272
```

```
~/TelegramBrazilianDoxxing $ cat consulta.json
```

```
{'status': 200, 'message': {'grauDeQualidade': '74%', 'cpf': '00000000272', 'cns': '700600973211961', 'score': '', 'nome': 'GHERSON DYWYNO ESPHYNDOLA', 'nascimento': 'SEXO: Masculino', 'sexo': 'Masculino', 'mae': 'Lhuzia Silva Roza Esphyndola', 'pai': 'REVUAN EH GAY E EU POSSO PROVAR', 'enderecoRecente': [{'resultado': '1', 'rua': 'Natividade', 'número': '109', 'distrito': 'Aurora Oeste', 'cidade': 'Goiania', 'estado': 'GO', 'cep': '74000000'}], 'telefonesRegistrados': [{'resultado': '1', 'numero': '999730541', 'tipo': 'INDEFINIDO', 'status': 'INDEFINIDO', 'operadora': 'INDEFINIDO'}, {'resultado': '2', 'numero': '6133152425', 'tipo': 'INDEFINIDO', 'status': 'INDEFINIDO', 'operadora': 'INDEFINIDO'}], 'emailsRegistrados': [{'resultado': '1', 'email': 'josedascouves001@gmail.com', 'senha': 'INDEFINIDO', 'tel. associado': '999730541', 'extra': 'SEM INFO EXTRA'}, {'resultado': '2', 'email': 'vivianneadolfo@hotmail.com', 'senha': 'INDEFINIDO', 'tel. associado': 'INDEFINIDO', 'extra': 'Email cadastrado no www.farmadelivery.com.br'}, {'resultado': '3', 'email': 'gamercachimba@gmail.com', 'senha': 'INDEFINIDO', 'tel. associado': 'INDEFINIDO', 'extra': 'Email cadastrado no www.farmadelivery.com.br'}, {'resultado': '4', 'email': 'ariela-mamoni@tuamaeaquelaursa.com', 'senha': 'INDEFINIDO', 'tel. associado': 'INDEFINIDO', 'extra': 'Email cadastrado no www.farmadelivery.com.br'}, {'resultado': '5', 'email': 'phantomile2@ig.com.br', 'senha': 'INDEFINIDO', 'tel. associado': 'INDEFINIDO', 'extra': 'SEM INFO EXTRA'}], 'vacinasRegistradas': 'NENHUMA VACINA REGISTRADA', 'receitaFederal': [{'numerorg': '35500024277'}, {'orgao_emissor': 'NÃO DEFINIDO'}, {'data_emissao': 'INDEFINIDO'}]}}
```
