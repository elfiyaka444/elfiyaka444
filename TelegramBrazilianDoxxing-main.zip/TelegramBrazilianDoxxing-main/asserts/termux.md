```
  pkg upgrade && pkg update -y
```

```
  pkg install git python -y
```

```
  git clone https://github.com/Kiny-Kiny/TelegramBrazilianDoxxing
```

```
  cd TelegramBrazilianDoxxing
```

```
  python3 -m pip install -r requirements.txt
```

```
  python3 main.py
```
