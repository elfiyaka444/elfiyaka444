<h2 align="center">Choose:</h2>

<p align="center">
  <a href="https://github.com/Kiny-Kiny/TelegramBrazilianDoxxing/blob/main/asserts/termux.md">Termux</a> •
  <a href="https://github.com/Kiny-Kiny/TelegramBrazilianDoxxing/blob/main/asserts/debian">Debian</a> •
  <a href="https://github.com/Kiny-Kiny/TelegramBrazilianDoxxing/blob/main/asserts/arch_linux">Arch Linux</a> •
  <a href="https://github.com/Kiny-Kiny/TelegramBrazilianDoxxing/blob/main/asserts/opensuse">OpenSUSE</a>
</p>

